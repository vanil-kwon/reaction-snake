const CACHE='reaction-snake-v1';
const FILES=['./','./index.html','./manifest.json','./css/main.css','./js/app.js','./js/engine.js','./js/controls.js','./js/storage.js','./js/modes/adaptive.js','./js/modes/classic.js','./js/statistics.js','./js/main.js','./assets/icon.svg'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return r}).catch(()=>caches.match('./index.html'))))});
